/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventario;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

public class producto 
{
    private int Folio;
    private String Nombre;
    private String Categoria;
    private int Precio;
    private int Cantidad;
    //declaracion de las varibales tipo privadas 

    public producto(int Folio, String Nombre, String Categoria, int Precio, int Cantidad) 
    {
        this.Folio = Folio;
        this.Nombre = Nombre;
        this.Categoria = Categoria;
        this.Precio = Precio;
        this.Cantidad = Cantidad;
    }//contructor de las variablees para utilizarlas en cualquier clase dentro del proyecto

   public  producto() {
         }

   


    public int getFolio() {
        return Folio;
    }

    public void setFolio(int Folio) {
        this.Folio = Folio;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setCategoria(String Categoria) {
        this.Categoria = Categoria;
    }

    public int getPrecio() {
        return Precio;
    }

    public void setPrecio(int Precio) {
        this.Precio = Precio;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }
//metodos get y set de las variables que utilizaremos 
    void almacenar(PrintWriter Escribe) 
    {
        Escribe.println(Folio);
        Escribe.println(Nombre);
        Escribe.println(Categoria);
        Escribe.println(Precio);
        Escribe.println(Cantidad);
        
        }

   public producto cargar(BufferedReader Almacen) {
         int Fo,Pre,Cant;
        String Nom,Cat;
        try
        {
            Fo=Integer.parseInt(Almacen.readLine());
            Nom=Almacen.readLine();
            Cat=Almacen.readLine();
            Pre=Integer.parseInt(Almacen.readLine());
            Cant=Integer.parseInt(Almacen.readLine());
            return new producto(Fo,Nom,Cat,Pre,Cant);
        }
        catch(IOException | NumberFormatException e){} //To change body of generated methods, choose Tools | Templates.
        return null;
    }
    
}
