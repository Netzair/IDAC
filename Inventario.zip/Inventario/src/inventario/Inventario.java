
package inventario;

public class Inventario 
{
  
    public static void main(String[] args) 
    {
        menu r;
        r = new menu();
        r.setVisible(true);
        r.setLocationRelativeTo(null);
        
    }
    
}
