<header>
    <div class="menu">
        <div class="left-side">
            <img id="imglogotec" src="/IDAC/Imagenes/Logo Tec.png" alt="img" />
        </div>
        <div class="middle-side">
            <label>TecNM Campus San Marcos<br>Aplicación web IDAC</label>
        </div>
        <div class="right-side">
            
        </div>
    </div>
</header>
