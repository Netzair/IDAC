<footer>
    <br><br><br><br>
    <table class="txtfooter">
        <tr>
            <td>Dirección</td>
        </tr>
        <tr>
            <td>Carretera Tecomate, Pesquería Km.1, C.P 39960, San Marcos, Gro., México.</td>
        </tr>
    </table>

    <table class="txtfooter">
        <tr>
            <td>Contacto</td>
        </tr>
        <tr>
            <td>Emails:admon_smarcos@tecnm.mx</td>
        </tr>
    </table>
    <a href="https://www.facebook.com/">
        <img class="icoredes" src="/IDAC/Iconos/facebook.png" alt="img2" /></a>
    <a href="https://www.google.com/">
        <img class="icoredes" src="/IDAC/Iconos/gmail.png" alt="img3" /></a>
    <a href="https://web.whatsapp.com/">
        <img class="icoredes" src="/IDAC/Iconos/whatsapp.png" alt="img4" /></a>
    <br><br>

</footer>