<?php
session_start();
session_destroy();
header("Location: /IDAC/index.php");

exit;
?>
