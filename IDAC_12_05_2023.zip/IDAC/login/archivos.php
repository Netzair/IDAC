<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

    <link rel="stylesheet" href="../css/estyle.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asignación_Materia</title>
    
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js"
		integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ"

		crossorigin="anonymous"> </script>
</head>
<body>
    

<div class="menu">
    <img id="imglogotec" src="/proyectoIDAC1/Imagenes/Logo Tec.png" alt="img" />
    <div class="txtitsm">
    <label aling="center"class="titulo" >TecNM Campus San Marcos <br>Aplicación web IDAC</label>
    </div>
    </div>
      

	
	<!--
		<div class="d-flex flex-column bd-highlight position-fixed p-3 bg-light" style="width: 200px;,">
			<h2>Menú</h2>
			<a class="btn btn-primary mt-2" href="#inicio" role="button">Inicio</a>
			<a class="btn btn-primary mt-2" href="#portafolio" role="button">Portafolio</a>
			<a class="btn btn-primary mt-2" href="#manual" role="button">Manual</a>
		</div>
	-->

	<div class="container-fluid">
		<div class="row">

			<div id="button" class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
				<div id="button_1" class="d-flex flex-column bd-highlight position-fixed p-3 bg-light"
					style="width: 200px;">
					<h2>Menú</h2>
					<a id="index_1" class="btn btn-primary mt-2" href="/IDAC/login/jefeige.php" role="button">Volver</a>
					<a id="index_1" class="btn btn-primary mt-2" href="/IDAC/login/registro/registro.php" role="button">Registrar Docentes</a>
					<a id="index_1" class="btn btn-primary mt-2" href="Manual_Adm.html" role="button">Manual</a>
               <a id="index_1" class="btn btn-primary mt-2" href="accion/logout.php" role="button">Cerrar Sesión</a>
               
				</div>
			</div>

			<div id="campo" class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
				<div class="accordion" id="accordionExample">
					<div class="accordion-item">
						<h2 class="accordion-header">
                     <br>
							<h2>Asignación de Materias</h2>
							<br>
							<br>
                            
 <style>
    
label {
  display: block;
  margin-bottom: 5px;
}

select {
  width: 100%;
  padding: 10px;
  border-radius: 5px;
  border: 1px solid #ccc;
  background-color: #fff;
  font-size: 16px;
  line-height: 1.3;
  box-sizing: border-box;
  margin-bottom: 20px;
}

select option {
  font-size: 16px;
}</style> 
						    <label>Docente:</label><br>
								<select name="docente" required>
									<option value="">Seleccionar</option>
									<option value="">Antonio Vazquez Rodriguez</option>
									<option value="">Cristina Barrera de Jesus</option>
									<option value="">Leonardo Hernandez Valle</option>
									<option value="">Oscar Venancio Chora</option>
									<option value="">Nubia Joselyn Lopez Rea</option>
								</select><br>
								<label>Periodo:</label><br>
									<select name="Periodo" required>
										<option value="">Seleccionar</option>
										<option value="">Enero/Junio2023</option>
										<option value="">Agosto/Diciembre2023</option>
									</select><br>

							<br>
							<button class="accordion-button" type="button" data-bs-toggle="collapse"
								data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								<h4>Semestres:</h4>
							</button>
						</h2>
					</div>
					<div class="accordion-item">
						<h2 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
								data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
								Semestre 1
							</button>
						</h2>
						<div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<button class="btn btn-primary custom-button">
									<span class="d-block">Administracion para informática</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Fundamentos de insvestigación</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Fundamentos de programación</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Taller de ética</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Cálculo diferencial</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Desarrollo sustentable</span>
									<span class="d-block">+</span>
								</button>
							</div>
						</div>
					</div>
					<div class="accordion-item">
						<h2 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
								data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
								Semestre 2
							</button>
						</h2>
						<div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<button class="btn btn-primary custom-button">
									<span class="d-block">Administración de los Recursos y Función Inf.</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Física para Informática</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Programación Orientada a Objetos</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Contabilidad Financiera </span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Cálculo Integral </span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Matemáticas Discretas</span>
									<span class="d-block">+</span>
								</button>
							</div>
						</div>
					</div>
					<div class="accordion-item">
						<h2 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
								data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
								Semestre 3
							</button>
						</h2>
						<div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<button class="btn btn-primary custom-button">
									<span class="d-block">Fundamentos de Sistemas de Información</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Sistemas Electrónicos para Informática</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Estructura de Datos</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Costos Empresariales</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Álgebra lineal</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Probabilidad y Estadística</span>
									<span class="d-block">+</span>
								</button>
							</div>
						</div>
					</div>
					<div class="accordion-item">
						<h2 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
								data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
								Semestre 4
							</button>
						</h2>
						<div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<button class="btn btn-primary custom-button">
									<span class="d-block">Taller de investigación 1</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Arquitectura de computadoras</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Administración y organización de datos</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Fundamentos de telecomunicación</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Sistemas operativos 1</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Investigación de operaciones</span>
									<span class="d-block">+</span>
								</button>
							</div>
						</div>
					</div>

					<div class="accordion-item">
						<h2 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
								data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
								Semestre 5
							</button>
						</h2>
						<div id="collapseSix" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<button class="btn btn-primary custom-button">
									<span class="d-block">Análisis y Modelado de Sistemas de Información</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Tecnologías e Interfaces de Computadoras</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Fundamentos de Base de Datos</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Redes de Computadoras</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Sistemas Operativos II</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Taller de Legislación Informática 
										</span>
									<span class="d-block">+</span>
								</button>
							</div>
						</div>
					</div>
					<div class="accordion-item">
						<h2 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
								data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
								Semestre 6
							</button>
						</h2>
						<div id="collapseSeven" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<button class="btn btn-primary custom-button">
									<span class="d-block">Desarrollo e Implementación de Sistemas de Información</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Auditoría en Informática </span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Taller de Base de Datos </span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Interconectividad de Redes</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Desarrollo de Aplicaciones Web</span>
									<span class="d-block">+</span>
								</button>
								
							</div>
						</div>
					</div>
					<div class="accordion-item">
						<h2 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
								data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
								Semestre 7
							</button>
						</h2>
						<div id="collapseEight" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<button class="btn btn-primary custom-button">
									<span class="d-block">Calidad en los Sistemas de Información</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Fundamentos de Gestión de Servicios de TI</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Tópicos de Base de Datos </span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Administración de Servidores</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Programación en Ambiente Cliente/Servidor</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Taller de Investigación II </span>
									<span class="d-block">+</span>
								</button>
							</div>
						</div>
					</div>
					<div class="accordion-item">
						<h2 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
								data-bs-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
								Semestre 8
							</button>
						</h2>
						<div id="collapseNine" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<button class="btn btn-primary custom-button">
									<span class="d-block">Taller de Emprendedores</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Estrategias de Gestión de Servicios de TI</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Inteligencia de Negocios</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Desarrollo de Aplicaciones para Dispositivos Móviles</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block">Seguridad Informática</span>
									<span class="d-block">+</span>
								</button>
								
							</div>
						</div>
					</div>
					<div class="accordion-item">
						<h2 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
								data-bs-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
								Especialidad
							</button>
						</h2>
						<div id="collapseTen" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<button class="btn btn-primary custom-button">
									<span class="d-block">Fundamentos de Sistemas de Información</span>
									<span class="d-block">+</span>
								</button>
								<button class="btn btn-primary custom-button">
									<span class="d-block"></span>
									<span class="d-block">+</span>
								</button>
							</div>
						</div>
					</div>
					<br><br><br>


                    <input class="btniniciar" type="submit" value="Guardar">

				</div>
			</div>
		</div>


	</div>

</body>
</html>