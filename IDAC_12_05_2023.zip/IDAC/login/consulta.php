<?php
// Incluye el archivo de conexión a la base de datos
require_once '../config/conexion.php';

// Inicia la sesión
session_start();

// Obtiene el RFC de la sesión actual
$rfc = $_SESSION['rfc'];
conexion();
// Realiza la consulta en la base de datos
$query = "SELECT m.nombre, am.semestre FROM asig_materia am JOIN materia m ON am.clavemateria = m.clavemateria WHERE am.rfc = '$rfc'";
$resultado = mysqli_query($conn, $query);

// Si la consulta no arrojó resultados, muestra un mensaje
if (mysqli_num_rows($resultado) == 0) {
  echo "No se encontraron resultados.";
} else {
  // Si hay resultados, imprime la tabla HTML
  echo "<table>";
  echo "<thead>";
  echo "<tr><th>Nombre de la materia</th><th>Semestre</th></tr>";
  echo "</thead>";
  echo "<tbody>";
  while ($fila = mysqli_fetch_assoc($resultado)) {
    echo "<tr>";
    echo "<td>" . $fila['nombre'] . "</td>";
    echo "<td>" . $fila['semestre'] . "</td>";
    echo "</tr>";
  }
  echo "</tbody>";
  echo "</table>";
}

// Cierra la conexión a la base de datos
mysqli_close($conexion);
?>
