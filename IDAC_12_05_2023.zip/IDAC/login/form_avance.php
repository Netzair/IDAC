<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,
                initial-scale=1.0">
    <title>docentes</title>
    <link rel="stylesheet" href="../css/estyle.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"> </script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"
        integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE"
        crossorigin="anonymous"> </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js"
        integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ"
        crossorigin="anonymous"> </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<?php require_once('../componentes/header.php') ?>

<body>
    <div class="container-fluid">
        <div class="row">

            <div id="button" class="col-sm-12 col-md-4 col-lg-4
                            col-xl-4">
                <div id="button_1" class="d-flex flex-column
                                bd-highlight position-fixed p-3 bg-light" style="width: 200px;">
                    <h2>Menú</h2>
                    <a id="index_1" class="btn btn-primary mt-2" href="/IDAC/login/docente.php" role="button">Volver</a>
                    <a id="index_1" class="btn btn-primary mt-2" href="accion/logout.php" role="button">Cerrar
                        Sesión</a>

                </div>
            </div>

            <div class="container-fluid">
                <div class="row">
                    <div id="button" class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                        <!-- Aquí va el menú -->
                    </div>
                    <div id="table" class="col-sm-12 col-md-8 col-lg-8 col-xl-8">

                    <table>
                            <h2>Formulario</h2>
                            <thead>
                                <tr>
                                    <th>Cuantos años tenes?</th>
                                    <th>jajaja holis</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><input type="text" name=""></td>
                                    <td><input type="text" name=""></td>
                                    <td><input type="text" name=""></td>

                                </tr>
                            </tbody>
                        </table>

                        <table>
                            <thead>
                                <tr>
                                    <th>abuela</th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><input type="text" name=""></td>
                                    <td><input type="text" name=""></td>
                                    <td><input type="text" name=""></td>
                                    
                                </tr>
                                <tr>
                                <td><button>Guardar</button></td>
                                </tr>
                            </tbody>
                        </table>
                        <br><br>



                    </div>
                </div>
            </div>
</body>


</html>