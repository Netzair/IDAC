<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // obtener valores del formulario
    $rfc = $_POST['rfc'];
    $nombre = $_POST['nombre'];
    $appaterno = $_POST['appaterno'];
    $apmaterno = $_POST['apmaterno'];
    $correo = $_POST['correo'];
    $contrasena = $_POST['CONTRASEENA'];
    require_once('../../config/conexion.php');
    // insertar los valores en la base de datos
    $conn = conexion();
    $query = "INSERT INTO usuario (RFC, nombre, apellido_pa, apellido_ma, correo, contrasena, id_rol) 
              VALUES ('$rfc', '$nombre', '$appaterno', '$apmaterno', '$correo', '$contrasena', '2')";
    $result = mysqli_query($conn, $query);

    // verificar si la inserción fue exitosa
    if ($result) 
    {
        echo "<script>alert('Registro exitoso.');</script>";
    } 
    else 
    {
        echo "<script>alert('Error al registrar usuario.');</script>";
    }

    // cerrar la conexión
    mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/IDAC/css/estyle.css">
    <title>IDAC</title>
    <style>
        .titulo {
            font-family: Montserrat
        }
    </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

    <link rel="stylesheet" href="../css/estyle.css">
    <link rel="stylesheet" href="/IDAC/css/imagen/stilo_carrusel.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jefe de Ingenieria </title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"> </script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"
        integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE"
        crossorigin="anonymous"> </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js"
        integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ"
        crossorigin="anonymous"> </script>
</head>
<?php require_once('../../componentes/header.php') ?>

<body>
<body>
    
<div class="container-fluid">
        <div class="row">

            <div id="button" class="col-sm-12 col-md-4 col-lg-4
                            col-xl-4">
                <div id="button_1" class="d-flex flex-column
                                bd-highlight position-fixed p-3 bg-light" style="width: 200px;">
                    
                    <a id="index_1" class="btn btn-primary mt-2" href="/IDAC/login/jefeige.php" role="button">Volver</a>

                </div>
            </div>
            </div>
</div>
    <div class="cajaregistro">
        <section class="flex-container">
            <center>
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <br>
                    <br>
                    <h1>Registro</h1><br>
                    <label>RFC:</label>
                    <input type="text" name="rfc" required><br>

                    <label>Nombre:</label>
                    <input type="text" name="nombre" required><br>

                    <label>Apellido Paterno:</label>
                    <input type="text" name="appaterno" required><br>

                    <label>Apellido Materno:</label>
                    <input type="text" name="apmaterno" required><br>

                    <label>Correo electrónico:</label>
                    <input type="text" name="correo" required><br>

                    <label>Contraseña:</label>
                    <input type="password" id="password" name="password" required>
                    <br>
                    <input class="check" type="checkbox" onclick="mostrarPassword()">Mostrar contraseña
                    <br>
                    <input class="btniniciar" type="submit" value="Registrar">
                </form>
            </center>
        </section>
        <script>
            function mostrarPassword() {
                var x = document.getElementById("password");
                if (x.type === "password") {
                    x.type = "text";
                } else {
                    x.type = "password";
                }
            }
        </script>
    </div>
</body>



</html>