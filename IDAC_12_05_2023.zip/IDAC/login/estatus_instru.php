<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>estatus_instrumentacion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

	<link rel="stylesheet" href="../css/estyle.css">
</head>
<header>
	<div class="menu">
		<div class="left-side">
			<img id="imglogotec" src="/proyectoIDAC1/Imagenes/Logo Tec.png" alt="img" />
		</div>
		<div class="middle-side">
			<label>TecNM Campus San Marcos<br>Aplicación web IDAC</label>
		</div>
	</div>
</header>
<body>
<div class="container-fluid">
		<div class="row">

			<div id="button" class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
				<div id="button_1" class="d-flex flex-column bd-highlight position-fixed p-3 bg-light"
					style="width: 200px;">
					<h2>Menú</h2>
					<a id="index_1" class="btn btn-primary mt-2" href="/IDAC/login/registro/registro.php"
						role="button">Registrar Docentes</a>
					<a id="index_1" class="btn btn-primary mt-2" href="/IDAC/login/asig_materia.php" role="button">Asignación de
						Materias </a>
					<a id="index_1" class="btn btn-primary mt-2" href="" role="button">Instrumentación didáctica</a>
					<a id="index_1" class="btn btn-primary mt-2" href="" role="button">Avance programático del curso</a>
					<a id="index_1" class="btn btn-primary mt-2" href="Manual_Adm.html" role="button">Manual</a>
					<a id="index_1" class="btn btn-primary mt-2" href="accion/logout.php" role="button">Cerrar
						Sesión</a>

				</div>
			</div>

</body>
</html>