<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,
                initial-scale=1.0">
    <title>docentes</title>
    <link rel="stylesheet" href="../css/estyle.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"> </script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"
        integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE"
        crossorigin="anonymous"> </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js"
        integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ"
        crossorigin="anonymous"> </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<?php require_once('../componentes/header.php') ?>

<body>
    <div class="container-fluid">
        <div class="row">

            <div id="button" class="col-sm-12 col-md-4 col-lg-4
                            col-xl-4">
                <div id="button_1" class="d-flex flex-column
                                bd-highlight position-fixed p-3 bg-light" style="width: 200px;">
                    <h2>Menú</h2>
                    <a id="index_1" class="btn btn-primary mt-2" href="/IDAC/login/docente.php" role="button">Volver</a>
                    <a id="index_1" class="btn btn-primary mt-2" href="accion/logout.php" role="button">Cerrar
                        Sesión</a>

                </div>
            </div>



            <div class="container-fluid">
                <div class="row">
                    <div id="button" class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                        <!-- Aquí va el recuadro que hace que el formulario se alinea a la derecha-->
                    </div>
                    <div id="table" class="col-sm-12 col-md-8 col-lg-8 col-xl-8">
                        <!-- Aquí va el formulario -->

<style>
table {
  width: 100%;
  max-width: 100%;
  border-collapse: collapse;
}
thead {
  background-color: #f5f5f5;
}


select {
  width: 70%;
  height: 30px;
  border-radius: 3px;
  border: 1px solid #ccc;
  padding: 6px 10px;
  font-size: 16px;
  color: #555;
  background-color: white;
}
label{
    color: black;
}


</style>


                        <table>
                            <h2>Formulario</h2>
                            <thead>
                                <tr>
                                    <th>Periodo</th>
                                    <th>Actividades de aprendizaje</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                <td>
                                    <select name="periodo" style="width: 70%;">
                                        <option value="ENERO/JUN-2023">ENERO/JUN-2023</option>
                                        <option value="AGOSTO/ABRIL-2023">AGOSTO/ABRIL-2023</option>
                                        <option value="ENERO/JUNIO-2024">ENERO/JUNIO-2024</option>
                                        <option value="AGOSTO/ABRIL-2024">AGOSTO/ABRIL-2024</option>
                                        <option value="ENERO/JUNIO-2025">ENERO/JUNIO-2025</option>
                                        <option value="AGOSTO/ABRIL-2025">AGOSTO/ABRIL-2025</option>
                                        <option value="ENERO/JUNIO-2026">ENERO/JUNIO-2026</option>
                                        <option value="AGOSTO/ABRIL-2026">AGOSTO/ABRIL-2026</option>
                                        <option value="ENERO/JUNIO-2026">ENERO/JUNIO-2027</option>
                                        <option value="AGOSTO/ABRIL-2026">AGOSTO/ABRIL-2027</option>
                                    </select>
                                    </td>
                                    <td><input type="text" name=""></td>
                                </tr>
                            </tbody>
                        </table>

                        <table>
                            <thead>
                                <tr>
                                    <th>Actividades de enseñanza</th>
                                    <th>Desarrollo de competencias <br>genéricas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><input type="text" name=""></td>
                                    <td><input type="text" name=""></td>
                                </tr>
                            </tbody>
                        </table>

                        <table>
                            <thead>
                                <tr>
                                    <th>Hora practicas</th>
                                    <th>Horas teóricas de la unidad</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><input type="text" name=""></td>
                                    <td><input type="text" name=""></td>
                                </tr>
                            </tbody>
                        </table>
                        <table>
                            <thead>
                                <tr>
                                    <th>Indicadores</th>
                                    <th>Valor</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>A<input type="text" name=""></td>
                                    <td><input type="text" name=""></td>
                                </tr>
                                <tr>
                                    <td>B<input type="text" name=""></td>
                                    <td><input type="text" name=""></td>
                                </tr>
                                <tr>
                                    <td>C<input type="text" name=""></td>
                                    <td><input type="text" name=""></td>
                                </tr>
                                <tr>
                                    <td>D<input type="text" name=""></td>
                                    <td><input type="text" name=""></td>
                                </tr>
                                <tr>
                                    <td>E<input type="text" name=""></td>
                                    <td><input type="text" name=""></td>
                                </tr>
                                <tr>
                                    <td>F<input type="text" name=""></td>
                                    <td><input type="text" name=""></td>
                                </tr>
                               
                                <tr>
                                    <td><button>Guardar</button></td>
                                </tr>
                            </tbody>
                        
       <form>
		<label for="unidades" >Ingrese la cantidad de unidades:</label>
		<input type="number" id="unidades" name="unidades" min="1" max="10">
		
		<button type="button" onclick="crearTabla()">Crear</button>

		<div id="tablaEvidencias"></div>

		<br><br>

		
	</form>

	<script>
		function crearTabla() {
			// obtener la cantidad de unidades
			var cantidadUnidades = parseInt(document.getElementById("unidades").value);

			// validar que se haya ingresado una cantidad válida
			if (isNaN(cantidadUnidades) || cantidadUnidades < 1 || cantidadUnidades > 10) {
				alert("Por favor ingrese una cantidad válida entre 1 y 10");
				return;
			}

			// crear tabla para cada unidad
			var tablaHTML = "";
			for (var i = 1; i <= cantidadUnidades; i++) {
				tablaHTML += "<h2>Unidad #" + i + "</h2>";
				tablaHTML += "<table>";
				tablaHTML += "<tr><th>Evidencias</th><th>Seleccionar</th></tr>";
				tablaHTML += "<tr><td>Cuadro comparativo</td><td><input type='checkbox' name='unidad_" + i + "_evidencias[]' value='cuadro_comparativo'></td></tr>";
				tablaHTML += "<tr><td>Resumen</td><td><input type='checkbox' name='unidad_" + i + "_evidencias[]' value='resumen'></td></tr>";
				tablaHTML += "<tr><td>Exposición</td><td><input type='checkbox' name='unidad_" + i + "_evidencias[]' value='exposicion'></td></tr>";
				tablaHTML += "<tr><td>Video explicativo</td><td><input type='checkbox' name='unidad_" + i + "_evidencias[]' value='video_explicativo'></td></tr>";
				tablaHTML += "<tr><td>Reporte</td><td><input type='checkbox' name='unidad_" + i + "_evidencias[]' value='reporte'></td></tr>";
				tablaHTML += "<tr><td>Cuadro sinóptico</td><td><input type='checkbox' name='unidad_" + i + "_evidencias[]' value='cuadro_sinoptico'></td></tr>";
				tablaHTML += "<tr><td>Mapa mental</td><td><input type='checkbox' name='unidad_" + i + "_evidencias[]' value='mapa_mental'></td></tr>";
				tablaHTML += "<tr><td>Práctica</td><td><input type='checkbox' name='unidad_" + i + "_evidencias[]' value='practica'></td></tr>";
				tablaHTML += "<tr><td>Entrevista</td><td><input type='checkbox' name='unidad_" + i + "_evidencias[]' value='entrevista'></td></tr>";
				tablaHTML += "<tr><td>Mapa conceptual</td><td><input type='checkbox' name='unidad_" + i + "_evidencias[]' value='mapa_conceptual'></td></tr>";
				tablaHTML += "</table>";
			}

			// mostrar tabla
			document.getElementById("tablaEvidencias").innerHTML = tablaHTML;
		}
	</script></table>
                        <br>

                    </div>
                </div>
            </div>




        </div>
    </div>
</body>


</html>