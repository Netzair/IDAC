-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-05-2023 a las 19:34:31
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `idac`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asig_materia`
--

CREATE TABLE `asig_materia` (
  `id_asig_materia` int(4) NOT NULL,
  `id_usuario` int(3) NOT NULL,
  `clave_asignatura` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `asig_materia`
--

INSERT INTO `asig_materia` (`id_asig_materia`, `id_usuario`, `clave_asignatura`) VALUES
(1, 1, 'IFE-1004');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calendarizacion`
--

CREATE TABLE `calendarizacion` (
  `id_calendarizacion` int(4) NOT NULL,
  `parametrps` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `calendarizacion`
--

INSERT INTO `calendarizacion` (`id_calendarizacion`, `parametrps`) VALUES
(1, '16'),
(2, 'TP=Tiempo Rea'),
(3, 'TR=tiempo planeado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_temario`
--

CREATE TABLE `cat_temario` (
  `id_temario` int(4) NOT NULL,
  `plan_estudio` varchar(40) NOT NULL,
  `nombre_asig` varchar(40) NOT NULL,
  `carrera` varchar(40) NOT NULL,
  `caract_asignatura` text NOT NULL,
  `intension_didactica` text NOT NULL,
  `competencia_asign` varchar(200) NOT NULL,
  `analisis_por_comp` varchar(200) NOT NULL,
  `fuentes_informacion` text NOT NULL,
  `id_satca` int(11) NOT NULL,
  `clave_asignatura` varchar(15) NOT NULL,
  `id_temas` int(5) NOT NULL,
  `id_instrumentacion` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cat_temario`
--

INSERT INTO `cat_temario` (`id_temario`, `plan_estudio`, `nombre_asig`, `carrera`, `caract_asignatura`, `intension_didactica`, `competencia_asign`, `analisis_por_comp`, `fuentes_informacion`, `id_satca`, `clave_asignatura`, `id_temas`, `id_instrumentacion`) VALUES
(1, 'IINF-2010-220 ', 'Administración para informática', 'Ingeniería Informática', 'Esta asignatura aporta al perfil del Ingeniero en Informática en las siguientes competencias: \r\n Aplica conocimientos científicos y tecnológicos en el área informática para la solución de \r\nproblemas con un enfoque multidisciplinario. \r\n Aplica herramientas computacionales actuales y emergentes para optimizar los procesos en \r\nlas organizaciones. \r\n Crea y administra redes de computadoras, considerando el diseño, selección, instalación y \r\nmantenimiento para la operación eficiente de los recursos informáticos. \r\n Realiza consultorías relacionadas con la función informática para la mejora continua de la \r\norganización. \r\n Se desempeña profesionalmente con ética, respetando el marco legal, la pluralidad y la \r\nconservación del medio ambiente. \r\nPara integrarla, analiza la importancia del proceso administrativo, gestiona proyectos informáticos, \r\nimplementa estructuras organizacionales, conoce la planeación estratégica orientada a la competencia \r\ny las tendencias de los servicios informáticos orientados al negocio. \r\n \r\nEsta asignatura, al formar parte del segundo semestre, proporciona el sustento teórico para algunas \r\nasignaturas posteriores, tales como: Administración de los Recursos y Función Informática, Auditoría \r\nInformática, Fundamentos de Gestión de Servicios de TI, entre otras; enfocándose en las estrategias \r\nespecíficas de competencia que debe desarrollar el estudiante. De forma particular, esta asignatura se \r\ncentra en identificar y evaluar las herramientas administrativas modernas para las organizaciones, \r\ncontribuyendo con ello a incrementar la competitividad en las mismas, teniendo como base la \r\nimplementación de nuevas tecnologías de información y comunicaciones.', 'Esta asignatura aporta al perfil del Ingeniero en Informática en las siguientes competencias: \r\n Aplica conocimientos científicos y tecnológicos en el área informática para la solución de \r\nproblemas con un enfoque multidisciplinario. \r\n Aplica herramientas computacionales actuales y emergentes para optimizar los procesos en \r\nlas organizaciones. \r\n Crea y administra redes de computadoras, considerando el diseño, selección, instalación y \r\nmantenimiento para la operación eficiente de los recursos informáticos. \r\n Realiza consultorías relacionadas con la función informática para la mejora continua de la \r\norganización. \r\n Se desempeña profesionalmente con ética, respetando el marco legal, la pluralidad y la \r\nconservación del medio ambiente. \r\nPara integrarla, analiza la importancia del proceso administrativo, gestiona proyectos informáticos, \r\nimplementa estructuras organizacionales, conoce la planeación estratégica orientada a la competencia \r\ny las tendencias de los servicios informáticos orientados al negocio. \r\n \r\nEsta asignatura, al formar parte del segundo semestre, proporciona el sustento teórico para algunas \r\nasignaturas posteriores, tales como: Administración de los Recursos y Función Informática, Auditoría \r\nInformática, Fundamentos de Gestión de Servicios de TI, entre otras; enfocándose en las estrategias \r\nespecíficas de competencia que debe desarrollar el estudiante. De forma particular, esta asignatura se \r\ncentra en identificar y evaluar las herramientas administrativas modernas para las organizaciones, \r\ncontribuyendo con ello a incrementar la competitividad en las mismas, teniendo como base la \r\nimplementación de nuevas tecnologías de información y comunicaciones.\r\nComo parte de la planeación informática, el estudiante considera la planeación estratégica en el tercer \r\ntema, con el que desarrolla una estrategia básica en el impulso de productos y servicios informáticos. \r\nCon el tema numero cuatro, demuestra las fases del proceso de marketing en el desarrollo y gestión de \r\nproductos o servicios informáticos de calidad. \r\nFinalmente con el quinto tema maneja herramientas que auxilian a las empresas en su evolución en \r\nfunción de sus procesos administrativos con tecnologías de información y comunicaciones. \r\nManeja un proyecto integrador a lo largo del semestre donde aplica los conceptos estudiados. \r\nComprueba la utilidad en el desempeño profesional, independientemente de lo que representa en el \r\ntratamiento de temas en asignaturas posteriores. \r\n \r\nCuenta con habilidades producto de las actividades prácticas, que promueven el trabajo en equipo; \r\nasimismo, propician procesos intelectuales como inducción-deducción y análisis-síntesis, con la \r\nintención de generar una actividad intelectual compleja. \r\n \r\nLa lista de actividades de aprendizaje no es exhaustiva, se sugieren sobre todo las necesarias para hacer \r\nmás significativo y efectivo el aprendizaje. Algunas de las actividades sugeridas pueden hacerse como \r\nactividad extra clase y comenzar el tratamiento en clase a partir de la discusión de los resultados de las \r\nobservaciones. \r\nEn el transcurso de las actividades programadas, es muy importante que el estudiante aprenda a valorar \r\nlas actividades que lleva al cabo y entienda que está construyendo su futuro y en consecuencia actúe \r\nde una manera profesional. De igual manera, aprecie la importancia del conocimiento y los hábitos de \r\ntrabajo; desarrolle la precisión y la curiosidad, la puntualidad, el entusiasmo y el interés, la tenacidad, \r\nla flexibilidad y la autonomía.', 'Conoce, identifica y aplica los elementos del proceso administrativo para optimizar los recursos en un contexto informático. ', 'Planea el proceso administrativo para desarrollar \r\nproyectos informáticos competitivos. ', '1. Abad Grau, M. d., & Antonio, G. P. (2011). Informatica aplicada a la gestion de empresa.\r\nMexico: Pirámide. \r\n2. Alvarez, A. (2011). Estrategia, planeación y control de la empresa. DUrango: Ra - Ma. \r\n3. Jimenez, R. H. (2010). Administración de la función Informatica. Mexico: Limusa. \r\n4. Sandhusen, R. L. (2012). Mercadotecnia. CECSA. \r\n5. Urbina, G. B. (2010). Evaluación de proyectos. México: Mc Graw Hill. \r\n6. Valinas, R. F. (s.f.). Fundamentos de mercadotecnia. Mexico: Thomson. ', 1, 'IFE-1004', 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `indicadores`
--

CREATE TABLE `indicadores` (
  `id_indicadores` int(4) NOT NULL,
  `indicadores` text NOT NULL,
  `valores_indicados` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `indicadores`
--

INSERT INTO `indicadores` (`id_indicadores`, `indicadores`, `valores_indicados`) VALUES
(1, 'A. Se adapta a situaciones y contextos complejos. \r\nEl estudiante puede trabajar en equipo, reflejar sus conocimientos en la práctica del modelo \r\ncon ejemplos reales, incluye más variables en casos d, B. Hace aportaciones a las actividades académicas desarrolladas.\r\nPregunta ligando conocimiento. Presenta otros puntos de vista que complementan al \r\npresentado en la clase. Presenta fuentes de información adicionales, revistas especializadas, \r\nmanuales, consulta fuentes en un segundo idioma, entre otras para la solución de los casos, C. Propone y/o explica soluciones o procedimientos no vistos en clase.\r\nAplica procedimientos aprendidos en otra asignatura para la elaboración de sus actividades., D. Introduce recursos y experiencias que promueven un pensamiento crítico.\r\nIntroduce cuestionamientos de tipo histórico, político, Administrativo, económico. Que \r\ndeben tomarse en cuenta para comprender mejor la programación. Se apoya en foros, \r\ndocumentales, o trae ejemplos del tema de servidores., E. Incorpora conocimientos y actividades interdisciplinarias en su aprendizaje.\r\nIncorpora conocimiento y actividades desarrollados en otras asignaturas para lograr la, F. Realiza su trabajo de manera autónoma y autorregulada. \r\nElabora una investigación diaria con el objetivo de participar activamente en las clases y \r\ncorregir sus dudas para la elaboración de sus actividades a entregar. El estudiante demuestra \r\ninterés en la clase al participar de manera sustentable.\r\n', '30, 40, 10'),
(3, 'B. Hace aportaciones a las actividades académicas desarrolladas.\r\nPregunta ligando conocimiento. Presenta otros puntos de vista que complementan al \r\npresentado en la clase. Presenta fuentes de inform', '10'),
(4, 'C. Propone y/o explica soluciones o procedimientos no vistos en clase.\r\nAplica procedimientos aprendidos en otra asignatura para la elaboración de sus actividades.', '20'),
(5, 'D. Introduce recursos y experiencias que promueven un pensamiento crítico.\r\nIntroduce cuestionamientos de tipo histórico, político, Administrativo, económico. Que \r\ndeben tomarse en cuenta para compre', '20'),
(6, 'E. Incorpora conocimientos y actividades interdisciplinarias en su aprendizaje.\r\nIncorpora conocimiento y actividades desarrollados en otras asignaturas para lograr la competencia de la unidad temátic', '10'),
(7, 'F. Realiza su trabajo de manera autónoma y autorregulada. \r\nElabora una investigación diaria con el objetivo de participar activamente en las clases y \r\ncorregir sus dudas para la elaboración de sus a', '20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `instrumentacion_didactica`
--

CREATE TABLE `instrumentacion_didactica` (
  `id_instrumentacion` int(4) NOT NULL,
  `periodo` varchar(30) NOT NULL,
  `activ_ensenanza` text NOT NULL,
  `activ_aprendizaje` text NOT NULL,
  `hrs_teoricas` varchar(10) NOT NULL,
  `hrs_practicas` varchar(10) NOT NULL,
  `id_indicadores` int(4) NOT NULL,
  `id_productos` int(4) NOT NULL,
  `id_calendarizacion` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `instrumentacion_didactica`
--

INSERT INTO `instrumentacion_didactica` (`id_instrumentacion`, `periodo`, `activ_ensenanza`, `activ_aprendizaje`, `hrs_teoricas`, `hrs_practicas`, `id_indicadores`, `id_productos`, `id_calendarizacion`) VALUES
(1, 'Enero-Junio 2023', '• Investigar los conceptos de servidor y los\r\ntipos de servidores (con respecto de\r\nsu arquitectura) para su mejor comprensión.\r\n• Realizar un mapa conceptual comparativo de\r\nlas características de los servidores más\r\ncomunes para determinar las mejores\r\nopciones según su aplicación.\r\n• Realizar al menos una entrevista a un\r\nadministrador de servidores para comprender\r\nlas actividades que realiza, en alguna\r\norganización de su localidad.\r\n', 'Aplica evaluación diagnóstica a los \r\nestudiantes para medir el nivel de \r\ncompetencias previas de la asignatura.\r\n•Investiga y analiza el concepto, tipos y \r\ncaracterísticas de servidores para \r\nexplicarlo en clase virtual, solicitando la \r\nparticipación del estudiante mediante un \r\nforo y generar lluvia de ideas.\r\n•Solicita un reporte de investigación\r\nsobre los conceptos de servidor y los tipos \r\nde servidores (con respecto a su \r\narquitectura).\r\n•Solicita al estudiante un mapa \r\nconceptual sobre las características \r\nprincipales de Servidores más comunes.\r\n•Solicitar una entrevista virtual a un \r\nadministrador de servidores de una \r\norganización para comprender las \r\nactividades que realiza.\r\n•Explica mediante la técnica expositiva los \r\ndiferentes tipos de tareas más comunes \r\nque realizan los administradores de red y \r\nsite con respecto a los servidores.\r\n•Solicita al estudiante ver videos sobre \r\ntipos de Servidores que existen en el \r\nmercado para solicitar un video Análisis.', '5', '0', 1, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

CREATE TABLE `materia` (
  `clave_asignatura` varchar(15) NOT NULL,
  `nombremateria` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `materia`
--

INSERT INTO `materia` (`clave_asignatura`, `nombremateria`) VALUES
('IFE-1004', 'Administración para Informática ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_productos` int(4) NOT NULL,
  `productos` varchar(50) NOT NULL,
  `porcentaje_producto` int(2) NOT NULL,
  `evaluación_formativa` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_productos`, `productos`, `porcentaje_producto`, `evaluación_formativa`) VALUES
(1, 'Mapa Conceptual', 30, 'Rúbrica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `id_rol` int(3) NOT NULL,
  `nombre_rol` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id_rol`, `nombre_rol`) VALUES
(1, 'administrador'),
(2, 'docente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `satca`
--

CREATE TABLE `satca` (
  `id_satca` int(4) NOT NULL,
  `hrs_teorica` int(2) NOT NULL,
  `hrs_practicas` int(2) NOT NULL,
  `total` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `satca`
--

INSERT INTO `satca` (`id_satca`, `hrs_teorica`, `hrs_practicas`, `total`) VALUES
(1, 3, 1, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subtemas`
--

CREATE TABLE `subtemas` (
  `id_subtema` int(5) NOT NULL,
  `subtemas` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `subtemas`
--

INSERT INTO `subtemas` (`id_subtema`, `subtemas`) VALUES
(1, '1.1. Concepto e importancia. \r\n1.2. Principios administrativos. \r\n1.3. Proceso administrativo alineado a proyectos \r\ninformáticos. \r\n1.4. Planeación: inicio del éxito o fracaso. \r\n1.4.1. Tipología de la planeación. \r\n1.5. Teoría moderna de la organización.\r\n1.6. Áreas administrativas funcionales.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `temas`
--

CREATE TABLE `temas` (
  `id_temas` int(5) NOT NULL,
  `temas` text NOT NULL,
  `id_subtemas` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `temas`
--

INSERT INTO `temas` (`id_temas`, `temas`, `id_subtemas`) VALUES
(0, 'Tema 1. La administración en el contexto \r\ninformático.', 1),
(1, 'Tema 1. La administración en el contexto \r\ninformático.', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(3) NOT NULL,
  `RFC` varchar(15) NOT NULL,
  `contrasena` varchar(10) DEFAULT NULL,
  `id_rol` int(11) DEFAULT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `apellido_pa` varchar(30) DEFAULT NULL,
  `apellido_ma` varchar(30) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `RFC`, `contrasena`, `id_rol`, `nombre`, `apellido_pa`, `apellido_ma`, `correo`) VALUES
(1, 'OSVAL2023', '1234', 2, 'Osvaldo', 'Cruz', 'Suastegui', 'cruzsuasategui@gmail.com'),
(2, 'DIMB990804JL3', 'ITSM2023', 1, 'Brandon  Netzair', 'Diaz', 'Murga', '171230033@smarcos.tecnm.mx'),
(3, 'SAMA02023', '1234', 2, 'Samanta', 'Rizo', 'Zuñiga', '181230042@smarcos.tecnm.mx');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asig_materia`
--
ALTER TABLE `asig_materia`
  ADD PRIMARY KEY (`id_asig_materia`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `clave_asignatura` (`clave_asignatura`);

--
-- Indices de la tabla `calendarizacion`
--
ALTER TABLE `calendarizacion`
  ADD PRIMARY KEY (`id_calendarizacion`);

--
-- Indices de la tabla `cat_temario`
--
ALTER TABLE `cat_temario`
  ADD PRIMARY KEY (`id_temario`),
  ADD KEY `id_satca` (`id_satca`),
  ADD KEY `clave_asignatura` (`clave_asignatura`),
  ADD KEY `id_temas` (`id_temas`),
  ADD KEY `id_instrumentacion` (`id_instrumentacion`);

--
-- Indices de la tabla `indicadores`
--
ALTER TABLE `indicadores`
  ADD PRIMARY KEY (`id_indicadores`);

--
-- Indices de la tabla `instrumentacion_didactica`
--
ALTER TABLE `instrumentacion_didactica`
  ADD PRIMARY KEY (`id_instrumentacion`),
  ADD KEY `id_indicadores` (`id_indicadores`),
  ADD KEY `id_producto` (`id_productos`),
  ADD KEY `id_calendarizacion` (`id_calendarizacion`),
  ADD KEY `id_productos` (`id_productos`);

--
-- Indices de la tabla `materia`
--
ALTER TABLE `materia`
  ADD PRIMARY KEY (`clave_asignatura`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_productos`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `satca`
--
ALTER TABLE `satca`
  ADD PRIMARY KEY (`id_satca`);

--
-- Indices de la tabla `subtemas`
--
ALTER TABLE `subtemas`
  ADD PRIMARY KEY (`id_subtema`);

--
-- Indices de la tabla `temas`
--
ALTER TABLE `temas`
  ADD PRIMARY KEY (`id_temas`),
  ADD KEY `id_subtemas` (`id_subtemas`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `id_rol` (`id_rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asig_materia`
--
ALTER TABLE `asig_materia`
  MODIFY `id_asig_materia` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `calendarizacion`
--
ALTER TABLE `calendarizacion`
  MODIFY `id_calendarizacion` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `cat_temario`
--
ALTER TABLE `cat_temario`
  MODIFY `id_temario` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `indicadores`
--
ALTER TABLE `indicadores`
  MODIFY `id_indicadores` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `instrumentacion_didactica`
--
ALTER TABLE `instrumentacion_didactica`
  MODIFY `id_instrumentacion` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_productos` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `satca`
--
ALTER TABLE `satca`
  MODIFY `id_satca` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `subtemas`
--
ALTER TABLE `subtemas`
  MODIFY `id_subtema` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `asig_materia`
--
ALTER TABLE `asig_materia`
  ADD CONSTRAINT `asig_materia_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `asig_materia_ibfk_2` FOREIGN KEY (`clave_asignatura`) REFERENCES `materia` (`clave_asignatura`) ON DELETE CASCADE;

--
-- Filtros para la tabla `cat_temario`
--
ALTER TABLE `cat_temario`
  ADD CONSTRAINT `cat_temario_ibfk_1` FOREIGN KEY (`id_satca`) REFERENCES `satca` (`id_satca`) ON DELETE CASCADE,
  ADD CONSTRAINT `cat_temario_ibfk_2` FOREIGN KEY (`clave_asignatura`) REFERENCES `materia` (`clave_asignatura`) ON DELETE CASCADE,
  ADD CONSTRAINT `cat_temario_ibfk_3` FOREIGN KEY (`id_temas`) REFERENCES `temas` (`id_temas`) ON DELETE CASCADE,
  ADD CONSTRAINT `cat_temario_ibfk_4` FOREIGN KEY (`id_instrumentacion`) REFERENCES `instrumentacion_didactica` (`id_instrumentacion`) ON DELETE CASCADE;

--
-- Filtros para la tabla `instrumentacion_didactica`
--
ALTER TABLE `instrumentacion_didactica`
  ADD CONSTRAINT `instrumentacion_didactica_ibfk_1` FOREIGN KEY (`id_productos`) REFERENCES `productos` (`id_productos`) ON DELETE CASCADE,
  ADD CONSTRAINT `instrumentacion_didactica_ibfk_2` FOREIGN KEY (`id_indicadores`) REFERENCES `indicadores` (`id_indicadores`) ON DELETE CASCADE,
  ADD CONSTRAINT `instrumentacion_didactica_ibfk_3` FOREIGN KEY (`id_calendarizacion`) REFERENCES `calendarizacion` (`id_calendarizacion`) ON DELETE CASCADE;

--
-- Filtros para la tabla `temas`
--
ALTER TABLE `temas`
  ADD CONSTRAINT `temas_ibfk_1` FOREIGN KEY (`id_subtemas`) REFERENCES `subtemas` (`id_subtema`) ON DELETE CASCADE;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
