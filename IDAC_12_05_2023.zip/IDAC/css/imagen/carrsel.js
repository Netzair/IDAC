

var slides = document.querySelectorAll(".slider .slide");
var currentSlide = 0;

function nextSlide() {
  slides[currentSlide].style.display = "none";
  if (currentSlide === slides.length - 1) {
    currentSlide = 0;
  } else {
    currentSlide++;
  }
  slides[currentSlide].style.display = "block";
}
setInterval(nextSlide, 3000);


