<?php
function conexion()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "idac";

    // Crea la conexión
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Verifica la conexión
    if (!$conn) {
        die("Conexión fallida: " . mysqli_connect_error());
    }
    return $conn;
}
function validarUsuario($usuario, $contraseña)
{
    session_start(); // Iniciar la sesión
    $conn = conexion();

    // Escapar los valores para evitar inyecciones SQL
    $usuario = mysqli_real_escape_string($conn, $usuario);
    $contraseña = mysqli_real_escape_string($conn, $contraseña);

    // Crear la consulta SQL
    $sql = "SELECT u.*, r.id_rol
            FROM usuario u
            INNER JOIN rol r ON u.id_rol = r.id_rol
            WHERE u.RFC = '$usuario' AND u.contrasena = '$contraseña'";

    // Ejecutar la consulta SQL
    $result = mysqli_query($conn, $sql);

    // Verificar si la consulta SQL devolvió algún resultado
    if (mysqli_num_rows($result) > 0) {
        // El usuario y la contraseña son válidos
        $row = mysqli_fetch_assoc($result);
        $_SESSION['RFC'] = $row['RFC'];

        $_SESSION['id_rol'] = $row['id_rol'];

        mysqli_close($conn);

        // Redirigir al usuario dependiendo de su rol
        if ($_SESSION['id_rol'] == 1) { // Administrador  division de estudios 
           
            echo "<script>
            alert('Bienvenido Administrador: $usuario');
            window.location.href='/IDAC/login/jefeige.php';
          </script>";
                return false;
           
        } elseif ($_SESSION['id_rol'] == 2) { // Jefe departamento de Gestion y vinculacion
            echo "<script>
            alert('Bienvenido Docente $usuario');
            window.location.href='/IDAC/login/docente.php';
          </script>";
                return false;
        } else {
            echo "<script>
        alert('El usuario no tiene rol');
        window.location.href='/IDAC/index.php';
      </script>";
            return false;
        }
    } else {
        echo "<script>
        alert('Contraseña o Usuario Incorrecta');
        window.location.href='/IDAC/index.php';
      </script>";
        mysqli_close($conn);
        return false;
    }
}

?>